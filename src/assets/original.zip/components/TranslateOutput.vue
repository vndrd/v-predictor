<template>
  <div id="translateOutput">
    <h2>{{ translatedText }}</h2>
  </div>
</template>

<script>
export default {
  name: 'TranslateOutput',
  props:[
    "translatedText"
  ]
}
</script>

<style>
</style>
